import tkinter as tk
import tkinter.messagebox as msg
import search
from tkinter import ttk
import pymysql
import ID
import teasearch
import change
import insert1
import delete
def frame():
    window3=tk.Tk()
    window3.title('教师')
    window3.geometry('900x700')
    lable0 = tk.Label(window3, text='欢迎来到学生成绩管理系统', bg='pink', font=('微软雅黑', 50)).pack()  # 上
    lable1 = tk.Label(window3, text='请选择操作:', font=('微软雅黑', 20)).place(x=80, y=400)  # 下
    tk.Button(window3, text='查询学生', font=('微软雅黑', 15), width=10, height=2,command=teasearch.frame).place(x=350, y=250)
    tk.Button(window3, text='修改学生成绩', font=('微软雅黑', 15), width=10, height=2,command=change.frame).place(x=350, y=350)
    tk.Button(window3, text='录入学生', font=('微软雅黑', 15), width=10, height=2,command=insert1.frame).place(x=350, y=450)
    tk.Button(window3, text='shanchu学生', font=('微软雅黑', 15), width=10, height=2, command=delete.frame).place(x=350, y=550)

    window3.mainloop()

