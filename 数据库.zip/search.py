import tkinter as tk
import tkinter.messagebox as msg
from tkinter import ttk
import pymysql
import ID
def frame():
    global window
    window = tk.Tk()
    window.title('学生课程以及成绩查询')
    window.geometry('1200x700')


    lable1 = tk.Label(window, text='在此查询您所有的课程信息:', font=('微软雅黑', 20)).place(x=300, y=25)
    tk.Button(window,text='查询',font=('宋体', 12), width=10,command=search).place(x=650,y=25)
    global tree#建立树形图
    yscrollbar = ttk.Scrollbar(window, orient='vertical')#右边的滑动按钮
    tree = ttk.Treeview(window, columns=('1', '2', '3', '4', '5'), show="headings",yscrollcommand=yscrollbar.set)
    tree.column('1', width=150, anchor='center')
    tree.column('2', width=150, anchor='center')
    tree.column('3', width=150, anchor='center')
    tree.column('4', width=150, anchor='center')
    tree.column('5', width=150, anchor='center')
    tree.heading('1', text='课程号')
    tree.heading('2', text='课程名')
    tree.heading('3', text='教师号')
    tree.heading('4', text='教师名')
    tree.heading('5', text='成绩')
    tree.place(x=200, y=150)
    yscrollbar.place(x=955,y=150)
    window.mainloop()

def search():
    db = pymysql.connect(host="localhost", port=3306, user="root", passwd='root', charset="utf8", database="students")
    cursor = db.cursor()
    uid = ID.getid()
    sql = "select course.id,course.cname,teacher.id,teacher.name,score.score from course,teacher,score where score.sid='%s' and score.cid=course.id and teacher.id=course.tid" %(uid)
    cursor.execute(sql)
    results=cursor.fetchall()
    if results:
        l= len(results)
        for i in range(0,l):#查询到的结果依次插入到表格中
            tree.insert('',i,values=(results[i]))
    else:
        tree.insert('', 0,values=('查询不到结果','查询不到结果','查询不到结果','查询不到结果','查询不到结果'))
    db.close()
