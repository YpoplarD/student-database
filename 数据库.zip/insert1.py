import tkinter as tk
import tkinter.messagebox as msg
from tkinter import ttk
import pymysql
import ID
def frame():
    global window5

    window5 = tk.Tk()
    window5.title('新增学生')
    window5.geometry('1200x700')
    lable1 = tk.Label(window5, text='在此给您的课程新增学生', font=('微软雅黑', 20)).place(x=400, y=25)
    lable2 = tk.Label(window5, text='学号:', font=('微软雅黑', 15)).place(x=200, y=150)
    lable3 = tk.Label(window5, text='姓名:', font=('微软雅黑', 15)).place(x=350, y=150)
    lable4 = tk.Label(window5, text='性别:', font=('微软雅黑', 15)).place(x=500, y=150)
    lable7 = tk.Label(window5, text='年龄:', font=('微软雅黑', 15)).place(x=650, y=150)
    lable5 = tk.Label(window5, text='专业:', font=('微软雅黑', 15)).place(x=800, y=150)
    lable6 = tk.Label(window5, text='成绩:', font=('微软雅黑', 15)).place(x=1000, y=150)
    lable7 = tk.Label(window5, text='请输入您的课程号:', font=('微软雅黑', 15)).place(x=200, y=80)
    tk.Button(window5, text='添加', font=('宋体', 12), width=10, command=insert).place(x=800, y=85)
    global b_name
    b_name=tk.Entry(window5,font=('宋体', 15),width=8)
    b_name.place(x=400,y=155)
    global b_id
    b_id = tk.Entry(window5, font=('宋体', 15), width=10)
    b_id.place(x=250, y=155)
    global b_sex
    b_sex=tk.Entry(window5,font=('宋体', 15),width=5)
    b_sex.place(x=550,y=155)
    global b_age
    b_age=tk.Entry(window5,font=('宋体', 15),width=5)
    b_age.place(x=700,y=155)
    global b_prof
    b_prof=tk.Entry(window5,font=('宋体', 15),width=15)
    b_prof.place(x=850,y=155)
    global b_score
    b_score=tk.Entry(window5,font=('宋体', 15),width=5)
    b_score.place(x=1050,y=155)
    global c_id
    c_id = tk.Entry(window5, font=('宋体', 15), width=15)
    c_id.place(x=400, y=85)

    window5.mainloop()
def insert():
    db = pymysql.connect(host="localhost", port=3306, user="root", passwd='root', charset="utf8", database="students")
    cursor = db.cursor()
    uid = ID.getid()
    cql="select id from student where exists (select id from student where id = '%s')" %(b_id.get())
    bql = "select id from course where exists (select id from course where tid='%s' and id='%s')" % (uid,c_id.get())
    if cursor.execute(bql):
        if cursor.execute(cql):
            msq = "INSERT INTO score(sid,cid,score) values('%s','%s','%d') " % (b_id.get(), c_id.get(), int(b_score.get()))
            cursor.execute(msq)
            db.commit()
            msg.showinfo(title='成功！', message='学生录入成功！')
        else:
            sql = "INSERT INTO student(name,id,sex,age,prof) values('%s','%s','%s','%d','%s') " % (b_name.get(),b_id.get(),b_sex.get(),int(b_age.get()),b_prof.get())
            cursor.execute(sql)
            db.commit()
            msq = "INSERT INTO score(sid,cid,score) values('%s','%s','%d') " % (b_id.get(),c_id.get(),int(b_score.get()))
            cursor.execute(msq)
            db.commit()
            msg.showinfo(title='成功！', message='学生录入成功！')
    else:
        msg.showinfo(title='失败！', message='课程号输入错误！您没有教学该课程！')


    db.close()