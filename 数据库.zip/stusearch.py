import tkinter as tk
import tkinter.messagebox as msg
from tkinter import ttk
import pymysql
import ID

def frame():
    global wind
    wind = tk.Tk()
    wind.title('学生查询')
    wind.geometry('800x500')

    tk.Button(wind, text='确认显示信息', font=('宋体', 12), width=13, command=search).place(x=200, y=25)
    global tree1#建立树形图
    tree1 = ttk.Treeview(wind, columns=('1', '2', '3', '4', '5'), show="headings")
    tree1.column('1', width=80, anchor='center')
    tree1.column('2', width=80, anchor='center')
    tree1.column('3', width=80, anchor='center')
    tree1.column('4', width=80, anchor='center')
    tree1.column('5', width=80, anchor='center')
    tree1.heading('1', text='学号')
    tree1.heading('2', text='姓名')
    tree1.heading('3', text='性别')
    tree1.heading('4', text='年龄')
    tree1.heading('5', text='专业')
    tree1.place(x=100, y=100)
    wind.mainloop()



def search():
    db = pymysql.connect(host="localhost",port=3306, user= "root",passwd='root',charset="utf8",database="students")
    cursor = db.cursor()
    uid = ID.getid()
    sql = "SELECT student.id,student.name,student.sex,student.age,student.prof FROM student WHERE student.id='%s'" % (uid)
    cursor.execute(sql)
    results1=cursor.fetchall()
    if results1:
        h= len(results1)
        for n in range(0,h):#查询到的结果依次插入到表格中
            tree1.insert('',n,values=(results1[n]))
    else:
        tree1.insert('',0,values=('查询不到结果','查询不到结果','查询不到结果','查询不到结果','查询不到结果'))
    db.close()



