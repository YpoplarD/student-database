import tkinter as tk
import tkinter.messagebox as msg
from tkinter import ttk
import search
import stusearch
import ID
import datetime as dt#datetime
import pymysql

def frame():
    window2=tk.Tk()
    window2.title('学生')
    window2.geometry('700x600')
    lable0 = tk.Label(window2, text='欢迎来到学生管理系统', bg='pink', font=('微软雅黑', 50)).pack()  # 上

    lable1 = tk.Label(window2, text='请选择操作:', font=('微软雅黑', 20)).place(x=80, y=400)  # 下
    tk.Button(window2, text='查询学生信息', font=('微软雅黑', 15), width=10, height=2,command=stusearch.frame).place(x=350, y=250)
    tk.Button(window2, text='查询课程成绩信息', font=('微软雅黑', 15), width=15, height=2,command=search.frame).place(x=350, y=350)
    window2.mainloop()

