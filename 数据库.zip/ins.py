import pymysql.cursors
import time
import pickle

conn = pymysql.connect(host='localhost', port=3306, user='root', passwd='root', charset="utf8",database="students")
cursor = conn.cursor()
insert1 = "insert into course(id,tid,cname,prof) values('C201','T001','高等数学A','大数据');"
cursor.execute(insert1)
conn.commit()
insert = "insert into score(score,sid,cid) values('79','220203513','C201'),('89','220203518','C201'),('91','220203511','C201'),('46','220203509','C201');"
cursor.execute(insert)
conn.commit()