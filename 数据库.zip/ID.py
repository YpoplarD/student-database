import tkinter as tk
import tkinter.messagebox as msg
import pymysql.cursors
import initial
import manager
import reader

import m_operation
import r_operation
def id_check(a):#检查账号
    global id
    if a == '1':#在教师界面下登录，参数是1
    #把账号/密码框框里输入的字符串赋值给id/password
        id = manager.entry_name.get()
        password = manager.entry_key.get()
    else:#在学生界面下登录，参数是0
        id = reader.entry_name.get()
        password = reader.entry_key.get()
    getid()#最后得到id
    #连接数据库，root是你数据库的用户名，应该是默认的是root，qwer是你数据库的密码，library是你要连接的数据库名字
    db = pymysql.connect(host='localhost', port=3306, user='root', passwd='root', charset="utf8", database="students")
    #建立游标cursor，这个游标可以类比指针，这样理解比较直观
    cursor = db.cursor()
    if a == '0':
        sql = "SELECT password FROM student WHERE id='%s' AND job='%s'" % (id,a)
    elif a == '1':
        sql = "SELECT password FROM teacher WHERE id='%s' AND job='%s'" % (id, a)
    cursor.execute(sql) #sql语句被执行
    result = cursor.fetchone()#得到的结果返回给result数组
    if result:#如果查询到了账号存在
            if password == result[0]:#result[0]是数组中的第一个结果
                success_login(a)#密码对上了，进入对应的读者/管理员操作界面
            else:#有账号但密码没对上
               msg._show(title='错误！',message='账号或密码输入错误！')
    else:#没有账号
        msg._show(title='错误！',message='您输入的用户不存在！')
        if a=='1':
            manager.root1.destroy()#关闭登录小窗口，回到管理员界面
        elif a=='0':
            reader.root1.destroy()
    db.close()

def success_login(a):#成功登录
    if a == '1':
        manager.root1.destroy()
        manager.root.destroy()
        m_operation.frame()#销毁登录注册界面，跳转到教师的操作界面

    elif a == '0':
        reader.root1.destroy()
        reader.root.destroy()
        r_operation.frame()#销毁登录注册界面，跳转到学生的操作界面


def getid():
    return id
