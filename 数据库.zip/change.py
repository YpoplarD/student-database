import tkinter as tk
import tkinter.messagebox as msg
from tkinter import ttk
import pymysql
import ID
def frame():
    global window5

    window5 = tk.Tk()
    window5.title('学生成绩修改')
    window5.geometry('1200x700')
    lable1 = tk.Label(window5, text='在此查询您需要修改的学生', font=('微软雅黑', 20)).place(x=400, y=25)
    tk.Button(window5,text='查询',font=('宋体', 12), width=10,command=search).place(x=700,y=80)
    tk.Button(window5, text='修改', font=('宋体', 12), width=10, command=change).place(x=800, y=406)
    global b_name
    tk.Label(window5, text='学号：', font=('宋体', 15)).place(x=450, y=80)
    b_name=tk.Entry(window5,font=('宋体', 15),width=15)
    b_name.place(x=500,y=80)
    global b_no
    text1 = tk.IntVar()
    lable2 = tk.Label(window5, text='在此输入修改后的成绩（只能修改您教学的课程）：', font=('微软雅黑', 15)).place(x=200, y=400)
    b_no=tk.Entry(window5,textvariable=text1,width=15)
    b_no.place(x=650,y=406)
    global tree#建立树形图
    yscrollbar = ttk.Scrollbar(window5, orient='vertical')#右边的滑动按钮
    tree = ttk.Treeview(window5, columns=('1', '2', '3', '4', '5'), show="headings",yscrollcommand=yscrollbar.set)
    tree.column('1', width=150, anchor='center')
    tree.column('2', width=150, anchor='center')
    tree.column('3', width=150, anchor='center')
    tree.column('4', width=150, anchor='center')
    tree.column('5', width=150, anchor='center')
    tree.heading('1', text='学号')
    tree.heading('2', text='姓名')
    tree.heading('3', text='课程号')
    tree.heading('4', text='课程名')
    tree.heading('5', text='成绩')
    tree.place(x=200, y=150)
    yscrollbar.place(x=955,y=150)
    window5.mainloop()

def search():
    db = pymysql.connect(host="localhost",port=3306, user= "root",passwd='root',charset="utf8",database="students")
    cursor = db.cursor()
    uid = ID.getid()
    sql = "SELECT student.id,student.name,course.id,course.cname,score.score FROM course,student,score WHERE score.cid=course.id and score.sid=student.id and course.tid ='%s' and student.id='%s' and score.cid = course.id" %(uid,b_name.get())
    cursor.execute(sql)
    results=cursor.fetchall()
    if results:
        l= len(results)
        for i in range(0,l):#查询到的结果依次插入到表格中
            tree.insert('',i,values=(results[i]))
    else :
        tree.insert('', 0,values=('查询不到结果','查询不到结果','查询不到结果','查询不到结果','查询不到结果'))

    db.close()

def change():
    db = pymysql.connect(host="localhost", port=3306, user="root", passwd='root', charset="utf8",database="students")
    cursor = db.cursor()
    uid = ID.getid()
    bsc = int(b_no.get())
    msql = "UPDATE score SET score='%d' WHERE score.sid IN (select student.id from student where student.id='%s') AND score.cid IN (select course.id from course where course.tid='%s')" %(bsc,b_name.get(),uid)
    if bsc>=0 and bsc<=100:
        cursor.execute(msql)
        db.commit()  # 这句不可或缺，当我们修改数据完成后必须要确认才能真正作用到数据库里
        msg.showinfo(title='成功！', message='成绩已修改！')
    else:
        msg.showinfo(title='修改失败！', message='请输入一个0到100之间的整数！')
    db.close()
