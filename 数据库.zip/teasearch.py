import tkinter as tk
import tkinter.messagebox as msg
from tkinter import ttk
import pymysql
import ID
def frame():
    global window4
    window4 = tk.Tk()
    window4.title('学生课程以及成绩查询')
    window4.geometry('1200x700')
    lable1 = tk.Label(window4, text='在此查询您选定课程号的所有学生:', font=('微软雅黑', 20)).place(x=300, y=20)
    tk.Button(window4,text='查询',font=('宋体', 12), width=10,command=search).place(x=590,y=60)
    global tree#建立树形图
    yscrollbar = ttk.Scrollbar(window4, orient='vertical')#右边的滑动按钮
    tree = ttk.Treeview(window4, columns=('1', '2', '3', '4', '5','6'), show="headings",yscrollcommand=yscrollbar.set)
    tree.column('1', width=150, anchor='center')
    tree.column('2', width=150, anchor='center')
    tree.column('3', width=150, anchor='center')
    tree.column('4', width=150, anchor='center')
    tree.column('5', width=150, anchor='center')
    tree.column('6', width=150, anchor='center')

    tree.heading('1', text='学号')
    tree.heading('2', text='姓名')
    tree.heading('3', text='课程号')
    tree.heading('4', text='课程名')
    tree.heading('5', text='专业')
    tree.heading('6', text='成绩')
    tree.place(x=200, y=250)
    yscrollbar.place(x=1100,y=150)
    global c_id
    lable1 = tk.Label(window4, text='在此输入您指定的课程号（该课程的任课老师必须是您）:', font=('微软雅黑', 20)).place(x=200, y=20)
    c_id = tk.Entry(window4, font=('宋体', 15), width=15)
    c_id.place(x=400, y=60)
    global c1
    lable1 = tk.Label(window4, text='在此输入成绩需求，输入后只显示在该成绩以上的学生:', font=('微软雅黑', 20)).place(x=200, y=90)
    c1 = tk.Entry(window4, font=('宋体', 15), width=15)
    c1.place(x=880, y=99)
    global c2
    lable1 = tk.Label(window4, text='在此输入成绩需求，输入后只显示在该成绩以下的学生:', font=('微软雅黑', 20)).place(x=200, y=130)
    c2 = tk.Entry(window4, font=('宋体', 15), width=15)
    c2.place(x=880, y=139)
    window4.mainloop()

def search():
    db = pymysql.connect(host="localhost",port=3306, user= "root",passwd='root',charset="utf8",database="students")
    cursor = db.cursor()
    uid = ID.getid()
    sql = "SELECT student.id,student.name,course.id,course.cname,student.prof,score.score FROM course,student,score WHERE score.cid=course.id and score.sid=student.id and course.tid ='%s' and score.cid = '%s' and score.score>= '%d' and score.score<='%d'" %(uid,c_id.get(),int(c1.get()),int(c2.get()))
    cursor.execute(sql)
    results=cursor.fetchall()
    if results:
        l= len(results)
        for i in range(0,l):#查询到的结果依次插入到表格中
            tree.insert('',i,values=(results[i]))
        msg.showinfo(title='成功！', message="该分数段共有%s人" % (len(results)))
    else :
        tree.insert('', 0,values=('查询不到结果','查询不到结果','查询不到结果','查询不到结果','查询不到结果'))

    db.close()

