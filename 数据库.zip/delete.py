import tkinter as tk
import tkinter.messagebox as msg
from tkinter import ttk
import pymysql
import ID
def frame():
    global window5

    window5 = tk.Tk()
    window5.title('删除学生')
    window5.geometry('1200x700')
    lable1 = tk.Label(window5, text='在此输入学号删除学生', font=('微软雅黑', 20)).place(x=400, y=55)
    tk.Button(window5, text='添加', font=('宋体', 12), width=10,command=delete).place(x=700, y=155)
    global b_name
    b_name = tk.Entry(window5, font=('宋体', 15), width=10)
    b_name.place(x=400, y=155)
    window5.mainloop()
def delete():
    db = pymysql.connect(host="localhost", port=3306, user="root", passwd='root', charset="utf8", database="students")
    cursor = db.cursor()
    uid = ID.getid()
    aql="select score.sid from student,score,course where score.sid = '%s' and course.tid='%s' and score.cid =course.id" %(b_name.get(),uid)
    if cursor.execute(aql):
        sql = "delete from score where score.sid in (select id from student where id='%s') and score.cid in (select course.id from course where course.tid='%s')" % ( b_name.get(), uid)
        cursor.execute(sql)
        db.commit()
        msg.showinfo(title='成功！', message='学生删除成功！')
    else:
        msg.showinfo(title='失败！', message='学生删除失败！')
    db.close()

