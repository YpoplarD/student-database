import pymysql.cursors
import time
import pickle

conn = pymysql.connect(host='localhost', port=3306, user='root', passwd='Wenqi.030210', charset="utf8",database="students")
cursor = conn.cursor()

cursor.execute("show databases")
result = cursor.fetchall()
print(result)

cursor.execute("use students")

stu = """
create table student(
    id char(20) not null primary key, --学生学号
    name varchar(20) default null unique, --学生姓名
    sex char(2),--学生性别
    age int,--学生年龄
    prof char(20),--学生专业
    job char(2) default '0',--身份
    password char(20) default '123456'--密码，默认123456
    )default charset=utf8;
"""
cursor.execute(stu)
conn.commit()
tea = """
create table teacher(
    id char(20) not null primary key, --教师号
    name char(20) default null unique,--教师名
    sex char(2),--教师性别
    job char(2) default '1',--身份
    password char(20) default '123456'--密码，默认123456
    )default charset=utf8;
"""
cursor.execute(tea)
conn.commit()

course = """
create table course(
    id char(20) not null primary key,--课程号
    tid char(20) not null,--教师号
    cname char(20) default null unique,--课程名
    prof char(20) not null,--专业
    foreign key (tid) references teacher(id)
    )default charset=utf8;
"""
cursor.execute(course)
conn.commit()

score = """
create table score(
    score int,--成绩
    sid char(20) not null,--学生号
    cid char(20) not null,--课程号
    primary key(sid,cid),
    foreign key (cid) references course(id),
    foreign key (sid) references student(id)
    )default charset=utf8;
"""
cursor.execute(score)
conn.commit()

cursor.execute("show tables")
result = cursor.fetchall()
print(result)
